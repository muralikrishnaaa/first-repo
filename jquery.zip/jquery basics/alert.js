jQuery.fn.alertmethod=function(){
    return this.each(function(){
        alert("geeks for geeks in"+$(this).prop("tagname"));
    });
}