jQuery.fn.display=function(){
    return this.each(function(){
        alert("Element name:"+$(this).prop("tagname"));
    });
}